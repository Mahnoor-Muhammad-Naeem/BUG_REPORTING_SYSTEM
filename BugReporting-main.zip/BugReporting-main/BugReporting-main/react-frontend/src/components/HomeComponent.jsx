import PropTypes from 'prop-types'
import React, { Component } from 'react'


export default class HomeComponent extends Component {
   constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        
      </div>
    )
  }
}
